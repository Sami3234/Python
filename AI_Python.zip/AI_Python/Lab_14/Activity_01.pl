woman(mia).
woman(jody).

